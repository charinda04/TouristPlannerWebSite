<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tourplan extends Model
{
    //
}
