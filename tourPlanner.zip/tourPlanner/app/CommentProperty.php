<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentProperty extends Model
{
    //
}
